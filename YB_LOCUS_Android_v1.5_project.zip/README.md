# YB LOCUS Android v1.5

Mobile-first Android WebView wrapper for Naver Land commercial analysis.

## v1.5 fixes
- 평당을 앱 재실행 시 기본 단위로 강제하고, ㎡당 전환 옵션은 유지.
- 네이버 모바일 매물카드에도 `전용 평(㎡) · 평당가` 보조표시를 추가.
- `계약 137.42m² (전용113.7)`처럼 전용면적 뒤에 ㎡가 생략되는 모바일 표기를 정확히 파싱.
- 저가매물 TOP 3가 현재 거래유형을 따라감: 월세 화면이면 월세 평당가 최저 3건, 매매 화면이면 매매 평당가 최저 3건.
- 배후세대 조회는 WebView same-origin Naver API 세션을 우선 사용하고, 실패 시 네이티브 요청으로 폴백.
- 좌표 기반 cortarNo 조회가 실패하면 화면 상단 지역명(예: 송파구 송파동)을 이용해 `/api/regions/list` 계층에서 법정동 코드를 재해석.
- Android 네이티브 Naver API 폴백 요청에 현재 페이지 Referer와 Fetch 헤더를 추가.

Package: `com.yblocus.app`
Version: `1.5.0`
