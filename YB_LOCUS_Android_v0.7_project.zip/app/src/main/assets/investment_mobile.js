(() => {
  'use strict';
  if (!location.hostname.endsWith('land.naver.com')) return;
  if (window.__SANGA_INVEST_MOBILE__) return;
  window.__SANGA_INVEST_MOBILE__ = true;
  const APP_VERSION = '0.7.0';

  const ID = 'sanga-invest-panel';
  const LAUNCHER_ID = 'sanga-invest-launcher';
  const BACKDROP_ID = 'sanga-invest-backdrop';
  const DEFAULTS = {
    radius: 500,
    targetYield: 6.0,
    serviceKey: '',
    manualUnits: '',
    includeOfficetel: true,
    panelCollapsed: false,
    purchasePrice: '',
    loanRatio: 80,
    interestRate: 5.1,
    acquisitionCostRate: 5.0,
    tenantDeposit: '',
    tenantRent: '',
    vacancyRate: 5,
    ownerMonthlyCost: 0
  };
  let settings = {...DEFAULTS};
  let latest = null;
  let lastHref = location.href;
  let refreshTimer = null;
  let regionRefreshTimer = null;
  let lastCenterSignature = '';
  let typeSheetTimer = null;

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const fmt = (n, d=0) => Number.isFinite(n) ? n.toLocaleString('ko-KR', {maximumFractionDigits:d, minimumFractionDigits:d}) : '-';
  const clamp = (n,a,b) => Math.min(b,Math.max(a,n));
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  const TYPE_HIDE_LABELS = new Set([
    '아파트','재건축','오피스텔','빌라','아파트 분양권','오피스텔 분양권',
    '재개발','원룸','단독/다가구','전원주택','상가주택','토지','건물',
    '공장/창고','지식산업센터'
  ]);
  const TYPE_KEEP_LABELS = new Set(['상가','사무실']);

  function exactText(el){ return (el?.textContent || '').replace(/\s+/g,' ').trim(); }
  function findPropertyTypeSheet(){
    const headings = [...document.querySelectorAll('h1,h2,h3,h4,strong,b,span,div,p')]
      .filter(el => exactText(el) === '매물유형');
    for(const h of headings){
      let root=h;
      for(let i=0;i<7 && root;i++,root=root.parentElement){
        const t=exactText(root);
        if(t.includes('상가·업무·토지') && (t.includes('아파트') || t.includes('재건축')) && t.includes('상가')) return root;
      }
    }
    return null;
  }
  function clickableFor(el, root){
    let n=el;
    for(let i=0;i<4 && n && n!==root;i++,n=n.parentElement){
      if(n.matches?.('button,a,[role="button"],label,li')) return n;
    }
    return el;
  }
  function simplifyPropertyTypeSheet(){
    const root=findPropertyTypeSheet();
    const launcher=document.getElementById(LAUNCHER_ID);
    if(!root){
      document.documentElement.classList.remove('sanga-type-sheet-open');
      if(launcher) launcher.removeAttribute('aria-hidden');
      return;
    }
    document.documentElement.classList.add('sanga-type-sheet-open');
    if(launcher) launcher.setAttribute('aria-hidden','true');

    const nodes=[...root.querySelectorAll('button,a,[role="button"],label,li,div,span')];
    for(const el of nodes){
      const t=exactText(el);
      if(TYPE_HIDE_LABELS.has(t)){
        const item=clickableFor(el,root);
        item.classList.add('sanga-hide-property-type');
      } else if(TYPE_KEEP_LABELS.has(t)){
        const item=clickableFor(el,root);
        item.classList.add('sanga-keep-property-type');
      }
    }
    root.classList.add('sanga-property-sheet');
  }

  function cleanNums(nums){ return nums.filter(Number.isFinite).sort((x,y)=>x-y); }
  function mean(nums){
    const a=nums.filter(Number.isFinite);
    return a.length ? a.reduce((s,v)=>s+v,0)/a.length : NaN;
  }
  function median(nums){
    const a = cleanNums(nums);
    if(!a.length) return NaN;
    const m = Math.floor(a.length/2);
    return a.length%2 ? a[m] : (a[m-1]+a[m])/2;
  }
  function percentile(nums,p){
    const a=cleanNums(nums);
    if(!a.length) return NaN;
    if(a.length===1) return a[0];
    const pos=(a.length-1)*p, lo=Math.floor(pos), hi=Math.ceil(pos), w=pos-lo;
    return a[lo]*(1-w)+a[hi]*w;
  }
  function trimmedMean(nums, trim=.1){
    const a = cleanNums(nums);
    if(!a.length) return NaN;
    const k = Math.floor(a.length*trim);
    const b = a.slice(k, a.length-k || a.length);
    return b.reduce((s,v)=>s+v,0)/b.length;
  }
  function statPack(nums){
    const a=cleanNums(nums);
    return {
      count:a.length,
      mean:mean(a), median:median(a), trimmed:trimmedMean(a),
      p10:percentile(a,.10), p90:percentile(a,.90),
      min:a.length?a[0]:NaN, max:a.length?a[a.length-1]:NaN
    };
  }
  function haversine(lat1, lon1, lat2, lon2){
    const R=6371000, toRad=x=>x*Math.PI/180;
    const dLat=toRad(lat2-lat1), dLon=toRad(lon2-lon1);
    const a=Math.sin(dLat/2)**2+Math.cos(toRad(lat1))*Math.cos(toRad(lat2))*Math.sin(dLon/2)**2;
    return 2*R*Math.asin(Math.sqrt(a));
  }
  function bbox(lat, lon, radius){
    const dLat = radius/111320;
    const dLon = radius/(111320*Math.cos(lat*Math.PI/180));
    return {topLat:lat+dLat,bottomLat:lat-dLat,leftLon:lon-dLon,rightLon:lon+dLon};
  }
  function parseMoneyToManwon(text){
    if(!text) return NaN;
    const t=String(text).replace(/,/g,'').replace(/\(.*$/,'').trim();
    const e=t.match(/(\d+(?:\.\d+)?)억/);
    let n=e?parseFloat(e[1])*10000:0;
    const after=e?t.slice(e.index+e[0].length):t;
    const rest=after.match(/(\d+(?:\.\d+)?)/);
    if(rest) n+=parseFloat(rest[1]);
    if(!e && rest) n=parseFloat(rest[1]);
    return n;
  }
  function parseAreaPy(item){
    const spec = $('.spec', item)?.textContent || '';
    const nums = [...spec.matchAll(/([\d.]+)m²/g)].map(m=>parseFloat(m[1])).filter(Number.isFinite);
    if(!nums.length) return NaN;
    // 기존 확장프로그램과 동일하게 첫 면적값 기준. 네이버 표기 구조가 달라질 경우 가장 작은 면적을 전용면적으로 보정.
    let sqm = nums[0];
    if(nums.length>=2 && nums[1] < nums[0]) sqm = nums[1];
    return sqm*0.3025;
  }
  function parseFloor(item){
    const spec = $('.spec', item)?.textContent || '';
    const m=spec.match(/(?:^|,\s*)(B?\d+|지하\s*\d+)\s*\/\s*(\d+)층/);
    if(!m) return null;
    const s=m[1];
    if(/^B/i.test(s)) return -parseInt(s.slice(1),10);
    if(/^지하/.test(s)) return -parseInt(s.replace(/\D/g,''),10);
    return parseInt(s,10);
  }
  function annotateListings(){
    $$('.item_inner:not(.is-loading)').forEach((item)=>{
      const type=$('.type',item)?.textContent?.trim();
      const priceEl=$('.price',item);
      const priceText=priceEl?.childNodes?.[0]?.textContent?.trim() || priceEl?.textContent?.trim() || '';
      const areaPy=parseAreaPy(item);
      if(!priceEl || !type || !Number.isFinite(areaPy) || areaPy<=0) return;
      const clean=priceText.replace(/\(.*$/,'').replace(/~.*$/,'').trim();
      let label='';
      if(type==='매매'){
        const sale=parseMoneyToManwon(clean);
        if(Number.isFinite(sale)&&sale>0) label=`전용 ${fmt(areaPy,1)}평 · @${fmt(sale/areaPy,0)}만/평`;
      }else if(type==='월세'){
        const parts=clean.split('/');
        if(parts.length>=2){
          const rent=parseMoneyToManwon(parts[1]);
          if(Number.isFinite(rent)&&rent>0) label=`전용 ${fmt(areaPy,1)}평 · @${fmt(rent/areaPy,2)}만/평`;
        }
      }
      if(!label) return;
      let tag=item.querySelector('.sanga-inline-unit');
      if(!tag){
        tag=document.createElement('div');
        tag.className='sanga-inline-unit';
        priceEl.insertAdjacentElement('afterend',tag);
      }
      if(tag.textContent!==label) tag.textContent=label;
    });
  }
  function scanListings(){
    annotateListings();
    const rows=[];
    $$('.item_inner:not(.is-loading)').forEach((item, idx)=>{
      const type=$('.type',item)?.textContent?.trim();
      const priceText=$('.price',item)?.childNodes?.[0]?.textContent?.trim() || $('.price',item)?.textContent?.trim() || '';
      const areaPy=parseAreaPy(item);
      if(!type || !Number.isFinite(areaPy) || areaPy<=0) return;
      const clean=priceText.replace(/\(.*$/,'').replace(/~.*$/,'').trim();
      const floor=parseFloor(item);
      if(type==='매매'){
        const sale=parseMoneyToManwon(clean);
        if(Number.isFinite(sale)&&sale>0) rows.push({kind:'sale',price:sale,areaPy,unit:sale/areaPy,floor,raw:clean,idx});
      } else if(type==='월세'){
        const parts=clean.split('/');
        if(parts.length>=2){
          const deposit=parseMoneyToManwon(parts[0]);
          const rent=parseMoneyToManwon(parts[1]);
          if(Number.isFinite(rent)&&rent>0) rows.push({kind:'rent',deposit:Number.isFinite(deposit)?deposit:0,rent,areaPy,unit:rent/areaPy,floor,raw:clean,idx});
        }
      }
    });
    const sales=rows.filter(x=>x.kind==='sale'), rents=rows.filter(x=>x.kind==='rent');
    const saleStats=statPack(sales.map(x=>x.unit)), rentStats=statPack(rents.map(x=>x.unit));
    const saleMedian=saleStats.median, rentMedian=rentStats.median;
    const cheapSales=sales
      .map(x=>({...x, discount:Number.isFinite(saleMedian)&&saleMedian>0?(x.unit/saleMedian-1)*100:NaN}))
      .filter(x=>Number.isFinite(x.discount) && (x.unit<=saleStats.p10 || x.discount<=-10))
      .sort((a,b)=>a.unit-b.unit)
      .slice(0,8);
    return {
      rows,sales,rents,saleStats,rentStats,cheapSales,
      saleMedian,
      saleMean:saleStats.mean,
      saleTrimmed:saleStats.trimmed,
      saleP10:saleStats.p10,
      saleP90:saleStats.p90,
      saleMin:saleStats.min,
      saleMax:saleStats.max,
      rentMedian,
      rentMean:rentStats.mean,
      rentTrimmed:rentStats.trimmed,
      rentP10:rentStats.p10,
      rentP90:rentStats.p90,
      rentMin:rentStats.min,
      rentMax:rentStats.max,
      depositMedian:median(rents.map(x=>x.deposit)),
      rentAmountMedian:median(rents.map(x=>x.rent))
    };
  }
  function getCenter(){
    const href=decodeURIComponent(location.href);
    let m=href.match(/\/map\/([\d.]+):([\d.]+):(\d+):/i);
    if(m) return {lat:+m[1],lon:+m[2],zoom:+m[3]};
    m=href.match(/[?&#]ms=([\d.]+),([\d.]+),(\d+)/);
    if(m) return {lat:+m[1],lon:+m[2],zoom:+m[3]};
    m=href.match(/ms%3D([\d.]+)%2C([\d.]+)%2C(\d+)/i);
    if(m) return {lat:+m[1],lon:+m[2],zoom:+m[3]};
    return null;
  }
  async function naverJson(path){
    const url = /^https?:/i.test(path) ? path : `https://new.land.naver.com${path}`;
    const text = await externalFetch(url);
    try { return JSON.parse(text); }
    catch(e){ throw new Error('네이버 응답을 JSON으로 해석하지 못했습니다.'); }
  }
  function extractCortar(data){
    return data?.cortarNo || data?.region?.cortarNo || data?.cortar?.cortarNo || data?.result?.cortarNo || null;
  }
  function extractRegionName(data){
    return data?.cortarName || data?.region?.cortarName || data?.cortar?.cortarName || data?.result?.cortarName || data?.cortarName3 || '';
  }
  function normalizeComplex(x){
    const c=x?.complexDetail || x;
    const lat=+(c.latitude ?? c.lat ?? c.y ?? c.centerLat);
    const lon=+(c.longitude ?? c.lon ?? c.lng ?? c.x ?? c.centerLon);
    const hh=+(c.totalHouseholdCount ?? c.householdCount ?? c.totalHouseholdCnt ?? 0);
    return {no:String(c.complexNo ?? c.markerId ?? c.id ?? ''),name:c.complexName ?? c.name ?? '',lat,lon,hh,type:c.realEstateTypeCode ?? c.realEstateType ?? ''};
  }
  function collectComplexLikeObjects(root){
    const out=[]; const seen=new Set();
    function walk(v){
      if(!v || typeof v!=='object') return;
      if(Array.isArray(v)){v.forEach(walk);return;}
      const id=v.complexNo ?? v.markerId ?? v.id;
      if(id && (v.latitude!=null || v.lat!=null || v.longitude!=null || v.lon!=null || v.lng!=null || v.complexName || v.name)){
        const key=String(id); if(!seen.has(key)){seen.add(key);out.push(v);}
      }
      Object.values(v).forEach(walk);
    }
    walk(root); return out;
  }
  async function getComplexMarkers(cortarNo,type,center,radius){
    const b=bbox(center.lat,center.lon,radius);
    const q=new URLSearchParams({
      cortarNo:String(cortarNo), zoom:String(Math.max(15,center.zoom||16)), priceType:'RETAIL',
      realEstateType:type, tradeType:'', tag:'::::::::', rentPriceMin:'0', rentPriceMax:'900000000',
      priceMin:'0', priceMax:'900000000', areaMin:'0', areaMax:'900000000',
      showArticle:'false', sameAddressGroup:'false', isPresale:'true',
      leftLon:String(b.leftLon), rightLon:String(b.rightLon), topLat:String(b.topLat), bottomLat:String(b.bottomLat)
    });
    const data=await naverJson(`/api/complexes/single-markers/2.0?${q.toString()}`);
    return collectComplexLikeObjects(data).map(normalizeComplex).filter(x=>x.no);
  }
  async function getComplexesByRegion(cortarNo, type){
    const url=`/api/regions/complexes?cortarNo=${encodeURIComponent(cortarNo)}&realEstateType=${encodeURIComponent(type)}&order=`;
    const data=await naverJson(url);
    return (data?.complexList || data?.complexes || []).map(normalizeComplex).filter(x=>x.no);
  }
  async function getCortarsAround(center,radius){
    const deltaLat=(radius*0.85)/111320;
    const deltaLon=(radius*0.85)/(111320*Math.cos(center.lat*Math.PI/180));
    const pts=[[0,0],[deltaLat,0],[-deltaLat,0],[0,deltaLon],[0,-deltaLon],[deltaLat,deltaLon],[deltaLat,-deltaLon],[-deltaLat,deltaLon],[-deltaLat,-deltaLon]];
    const result=[];
    for(const [dy,dx] of pts){
      try{
        const d=await naverJson(`/api/cortars?zoom=${center.zoom||16}&centerLat=${center.lat+dy}&centerLon=${center.lon+dx}`);
        const no=extractCortar(d); if(no && !result.some(x=>x.no===no)) result.push({no,name:extractRegionName(d)});
      }catch(e){}
    }
    return result;
  }
  async function enrichComplex(c){
    if(Number.isFinite(c.lat)&&Number.isFinite(c.lon)&&c.hh>0) return c;
    try{
      const d=await naverJson(`/api/complexes/${encodeURIComponent(c.no)}?sameAddressGroup=false`);
      return normalizeComplex(d?.complexDetail || d);
    }catch(e){return c;}
  }
  async function getHouseholds(center, radius){
    const cortars=await getCortarsAround(center,radius);
    if(!cortars.length) throw new Error('행정동 코드를 찾지 못했습니다.');
    const types=settings.includeOfficetel?['APT','OPST']:['APT'];
    let complexes=[];
    for(const c of cortars){
      for(const t of types){
        try{
          const markers=await getComplexMarkers(c.no,t,center,radius);
          if(markers.length) complexes.push(...markers);
          else complexes.push(...await getComplexesByRegion(c.no,t));
        }catch(e){
          try{complexes.push(...await getComplexesByRegion(c.no,t));}catch(_e){}
        }
      }
    }
    const map=new Map(); complexes.forEach(c=>{if(c.no)map.set(c.no,c);}); complexes=[...map.values()];
    // 좌표가 있는 단지만 먼저 반경 필터링하여 상세조회 수를 줄인다. 좌표 없는 항목은 보수적으로 상세조회한다.
    const candidates=complexes.filter(c=>!Number.isFinite(c.lat)||!Number.isFinite(c.lon)||haversine(center.lat,center.lon,c.lat,c.lon)<=radius*1.15);
    const need=candidates.filter(c=>!(Number.isFinite(c.lat)&&Number.isFinite(c.lon)&&c.hh>0)).slice(0,140);
    for(let i=0;i<need.length;i+=8){
      const batch=need.slice(i,i+8);
      const enriched=await Promise.all(batch.map(enrichComplex));
      enriched.forEach(c=>{ if(c.no) map.set(c.no,c); });
      if(i+8<need.length) await sleep(50);
    }
    complexes=[...map.values()].filter(c=>Number.isFinite(c.lat)&&Number.isFinite(c.lon));
    complexes.forEach(c=>c.distance=haversine(center.lat,center.lon,c.lat,c.lon));
    const within=complexes.filter(c=>c.distance<=radius && Number.isFinite(c.hh) && c.hh>0);
    const hh=within.reduce((s,c)=>s+c.hh,0);
    return {households:hh,complexes:within.sort((a,b)=>a.distance-b.distance),cortarNo:cortars[0].no,regionName:cortars.map(x=>x.name).filter(Boolean).join(' · '),cortars:cortars.map(x=>x.no)};
  }
  async function externalFetch(url){
    return new Promise((resolve,reject)=>{
      chrome.runtime.sendMessage({type:'SANGA_FETCH',url},res=>{
        if(chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if(!res?.ok) return reject(new Error(res?.error || `공공데이터 응답 ${res?.status||''}`));
        resolve(res.text);
      });
    });
  }
  function totalCountFromResponse(text){
    try{
      const j=JSON.parse(text);
      const body=j?.response?.body ?? j?.body ?? j;
      const n=+(body?.totalCount ?? body?.totalcount ?? body?.items?.totalCount);
      if(Number.isFinite(n)) return n;
    }catch(e){}
    const m=text.match(/<totalCount>(\d+)<\/totalCount>/i) || text.match(/<totalcount>(\d+)<\/totalcount>/i);
    return m?+m[1]:NaN;
  }
  async function getStoreCount(center,radius){
    const key=(settings.serviceKey||'').trim();
    if(!key) return {count:NaN,source:'no-key'};
    const q=new URLSearchParams({radius:String(Math.min(2000,radius)),cx:String(center.lon),cy:String(center.lat),pageNo:'1',numOfRows:'1',type:'json',ServiceKey:key});
    const url=`https://apis.data.go.kr/B553077/api/open/sdsc2/storeListInRadius?${q.toString()}`;
    const text=await externalFetch(url);
    const count=totalCountFromResponse(text);
    if(!Number.isFinite(count)) throw new Error('상가업소 API 응답을 해석하지 못했습니다. 인증키(일반/Decoding)를 확인하세요.');
    return {count,source:'semas'};
  }
  function deriveScore(data){
    const {households,stores,radius,listings}=data;
    const areaKm2=Math.PI*(radius/1000)**2;
    const density=households/areaKm2;
    const densityScore=clamp((density-1500)/(9000-1500)*100,0,100);
    let supplyScore=50;
    if(Number.isFinite(stores)&&stores>0){
      const hhPerStore=households/stores;
      supplyScore=clamp((hhPerStore-2.5)/(10-2.5)*100,0,100);
    }
    let listingScore=50;
    if(households>0){
      const rentPer1000=(listings?.rents?.length||0)/households*1000;
      listingScore=clamp(100-rentPer1000*7,0,100);
    }
    const score=Math.round(densityScore*.45+supplyScore*.40+listingScore*.15);
    let label=score>=75?'수급 여건 강함':score>=60?'수급 여건 양호':score>=45?'수급 여건 보통':score>=30?'수급 여건 약함':'수급 여건 매우 약함';
    if(!Number.isFinite(stores)) label+=' · 잠정';
    return {score,label,density,densityScore,supplyScore,listingScore};
  }
  function inferredGrossYield(listings){
    if(!Number.isFinite(listings.saleMedian)||!Number.isFinite(listings.rentMedian)||listings.saleMedian<=0) return NaN;
    // 평당 매매가(만원)와 평당 월세(만원/월)의 단순 교차 중앙값 기준. 보증금은 서로 매칭되지 않아 제외.
    return listings.rentMedian*12/listings.saleMedian*100;
  }
  function capValue(depositMan, rentMan, yieldPct){
    if(!Number.isFinite(rentMan)||!Number.isFinite(yieldPct)||yieldPct<=0) return NaN;
    return depositMan + rentMan*12/(yieldPct/100);
  }
  function panel(){return document.getElementById(ID);}
  function mount(){
    if(panel()) return;
    const el=document.createElement('div'); el.id=ID;
    el.innerHTML=`
      <div class="sip-head"><div><div class="sip-title">YB LOCUS Android v0.7</div><div class="sip-sub">시세 · 저가후보 · 배후세대 · 상권수급</div></div><button data-act="closeSheet">닫기</button></div>
      <div class="sip-body">
        <div class="sip-score"><div class="sip-score-num" data-v="score">-</div><div class="sip-score-text"><b data-v="scoreLabel">분석 전</b><span><strong>높을수록 유리</strong> · 배후세대 대비 상가공급의 수급형 참고지표</span></div></div>
        <div class="sip-bar"><i data-v="scoreBar" style="width:0%"></i></div>
        <div class="sip-grid" style="margin-top:9px">
          <div class="sip-card"><b>배후세대</b><div class="sip-value" data-v="households">-</div><div class="sip-note" data-v="hhNote">반경 내 공동주택 기준</div></div>
          <div class="sip-card"><b>영업점 수</b><div class="sip-value" data-v="stores">-</div><div class="sip-note">소상공인 상가업소 API</div></div>
          <div class="sip-card"><b>세대 / 영업점</b><div class="sip-value" data-v="hhPerStore">-</div><div class="sip-note">높을수록 점포 공급이 상대적으로 적음</div></div>
          <div class="sip-card"><b>영업점 / 1천세대</b><div class="sip-value" data-v="storePer1000">-</div><div class="sip-note">낮을수록 점포 밀도가 낮음</div></div>
        </div>
        <div class="sip-section">
          <div class="sip-section-title"><span>현재 네이버 상가 호가</span><button data-act="rescan">매물 다시읽기</button></div>
          <table class="sip-table sip-stats"><thead><tr><th>구분</th><th>전체평균</th><th>중앙값</th><th>보정평균</th><th>건수</th></tr></thead><tbody>
            <tr><td>매매 평당</td><td data-v="saleMean">-</td><td data-v="saleMedian">-</td><td data-v="saleTrimmed">-</td><td data-v="saleCount">-</td></tr>
            <tr><td>월세 평당</td><td data-v="rentMean">-</td><td data-v="rentMedian">-</td><td data-v="rentTrimmed">-</td><td data-v="rentCount">-</td></tr>
          </tbody></table>
          <table class="sip-table sip-range" style="margin-top:6px"><thead><tr><th>구분</th><th>최저</th><th>하위10%</th><th>상위10%</th><th>최고</th></tr></thead><tbody>
            <tr><td>매매 평당</td><td data-v="saleMin">-</td><td data-v="saleP10">-</td><td data-v="saleP90">-</td><td data-v="saleMax">-</td></tr>
            <tr><td>월세 평당</td><td data-v="rentMin">-</td><td data-v="rentP10">-</td><td data-v="rentP90">-</td><td data-v="rentMax">-</td></tr>
          </tbody></table>
          <div class="sip-note"><b>저가 매물도 전부 통계에 포함합니다.</b> 전체평균은 실제 등록매물 전체를 반영하고, 중앙값·보정평균은 비교용으로 함께 제공합니다.</div>
          <div class="sip-lowbox"><div class="sip-lowtitle">저가 후보 <span>중앙값 대비 -10% 이상 또는 하위 10%</span></div><div data-v="cheapSales" class="sip-lowlist">매매 매물을 읽으면 표시됩니다.</div></div>
        </div>
        <div class="sip-section">
          <div class="sip-section-title"><span>수익가치 환산</span></div>
          <div class="sip-row"><label>목표수익률</label><input data-in="yield" type="number" min="1" max="20" step="0.1"><span>%</span></div>
          <div class="sip-grid">
            <div class="sip-card"><b>대표 보증금</b><div class="sip-value" data-v="depMed">-</div></div>
            <div class="sip-card"><b>대표 월세</b><div class="sip-value" data-v="rentAmtMed">-</div></div>
            <div class="sip-card sip-wide"><b>수익률 기준 환산가</b><div class="sip-value" data-v="capValue">-</div><div class="sip-note">보증금 + 연월세 ÷ 목표수익률</div></div>
          </div>
        </div>
        <div class="sip-section">
          <div class="sip-section-title"><span>대상물건 투자 계산기</span><button data-act="marketRentToCalc">대표 임대값 입력</button></div>
          <div class="sip-row"><label>매입가</label><input data-calc="purchasePrice" type="number" min="0" step="100" placeholder="예: 17300"><span>만원</span></div>
          <div class="sip-grid sip-calc-two">
            <div class="sip-minirow"><label>대출비율</label><input data-calc="loanRatio" type="number" min="0" max="100" step="1"><span>%</span></div>
            <div class="sip-minirow"><label>대출금리</label><input data-calc="interestRate" type="number" min="0" max="30" step="0.01"><span>%</span></div>
            <div class="sip-minirow"><label>부대비용률</label><input data-calc="acquisitionCostRate" type="number" min="0" max="30" step="0.1"><span>%</span></div>
            <div class="sip-minirow"><label>공실률</label><input data-calc="vacancyRate" type="number" min="0" max="100" step="1"><span>%</span></div>
          </div>
          <div class="sip-row"><label>임차보증금</label><input data-calc="tenantDeposit" type="number" min="0" step="100"><span>만원</span></div>
          <div class="sip-row"><label>월세</label><input data-calc="tenantRent" type="number" min="0" step="1"><span>만원</span></div>
          <div class="sip-row"><label>임대인 월비용</label><input data-calc="ownerMonthlyCost" type="number" min="0" step="1"><span>만원</span></div>
          <div class="sip-grid" style="margin-top:8px">
            <div class="sip-card"><b>예상 대출금</b><div class="sip-value" data-v="calcLoan">-</div></div>
            <div class="sip-card"><b>월 이자</b><div class="sip-value" data-v="calcMonthlyInterest">-</div></div>
            <div class="sip-card"><b>실투자금</b><div class="sip-value" data-v="calcCash">-</div></div>
            <div class="sip-card"><b>연 순현금흐름</b><div class="sip-value" data-v="calcAnnualCash">-</div></div>
            <div class="sip-card"><b>단순 임대수익률</b><div class="sip-value" data-v="calcGrossYield">-</div></div>
            <div class="sip-card"><b>대출후 현금수익률</b><div class="sip-value" data-v="calcRoe">-</div></div>
          </div>
          <div class="sip-note">단순 비교용입니다. 원금상환, 부가세, 소득세/법인세, 공실 중 관리비, 수선비 등은 별도 검토가 필요합니다. 부대비용률은 직접 수정하세요.</div>
        </div>
        <div class="sip-section">
          <div class="sip-section-title"><span>배후세대 조사</span><button data-act="refresh">지역 분석</button></div>
          <div class="sip-row"><label>분석 반경</label><select data-in="radius"><option value="300">300m</option><option value="500">500m</option><option value="1000">1km</option><option value="1500">1.5km</option><option value="2000">2km</option></select></div>
          <div class="sip-row"><label>주거오피스텔</label><select data-in="officetel"><option value="1">포함</option><option value="0">제외</option></select></div>
          <div class="sip-row"><label>상가 호실수</label><input data-in="manualUnits" type="number" min="0" placeholder="선택 입력"></div>
          <div class="sip-note" data-v="manualUnitKpi"></div>
          <div class="sip-row"><label>공공 API 키</label><input data-in="key" type="password" placeholder="data.go.kr Decoding 키"></div>
          <div class="sip-actions"><button data-act="apiPage">API 발급페이지</button><button data-act="formula">지수 산식</button></div>
          <div class="sip-actions"><button data-act="save">설정 저장</button><button data-act="copy">분석 복사</button><button data-act="csv">CSV 저장</button></div>
          <div class="sip-warning" style="margin-top:8px" data-v="warning">배후세대는 네이버 단지정보의 공동주택 세대수 합산입니다. 단독·다가구 등은 포함되지 않을 수 있습니다. 영업점 수는 '상가 호실 수'가 아니라 실제 상가업소 데이터입니다.</div>
        </div>
        <div class="sip-section"><div class="sip-section-title"><span>가까운 주거단지</span><span class="sip-muted" data-v="region">-</span></div><div data-v="complexes" class="sip-note">지역 분석을 누르세요.</div></div>
      </div>`;
    const backdrop=document.createElement('div');
    backdrop.id=BACKDROP_ID;
    backdrop.className='sip-backdrop sip-hidden';
    const launcher=document.createElement('button');
    launcher.id=LAUNCHER_ID;
    launcher.type='button';
    launcher.innerHTML='<span>📊</span> 상가분석';
    document.body.appendChild(backdrop);
    document.body.appendChild(el);
    document.body.appendChild(launcher);
    el.classList.add('sip-mobile-sheet','sip-sheet-closed');
    launcher.addEventListener('click',openSheet);
    backdrop.addEventListener('click',closeSheet);
    bindPanel(el);
    applyInputs();
  }
  function openSheet(){
    simplifyPropertyTypeSheet();
    const el=panel(), back=document.getElementById(BACKDROP_ID);
    if(el) el.classList.remove('sip-sheet-closed');
    if(back) back.classList.remove('sip-hidden');
    document.documentElement.classList.add('sanga-invest-sheet-open');
  }
  function closeSheet(){
    const el=panel(), back=document.getElementById(BACKDROP_ID);
    if(el) el.classList.add('sip-sheet-closed');
    if(back) back.classList.add('sip-hidden');
    document.documentElement.classList.remove('sanga-invest-sheet-open');
  }
  function setv(k,v){ const e=panel()?.querySelector(`[data-v="${k}"]`); if(e) e.textContent=v; }
  function bindPanel(el){
    el.addEventListener('click',e=>{
      const act=e.target?.dataset?.act; if(!act)return;
      if(act==='closeSheet') closeSheet();
      if(act==='rescan'){ latest=latest||{}; latest.listings=scanListings(); render(); }
      if(act==='refresh') refreshAll(true);
      if(act==='apiPage') { try{ SangaNative.openExternal(window.__SANGA_BRIDGE_TOKEN__||'', 'https://www.data.go.kr/data/15012005/openapi.do'); }catch(_e){ window.open('https://www.data.go.kr/data/15012005/openapi.do','_blank','noopener'); } }
      if(act==='formula') setv('warning','수급지수는 0~100점이며 높을수록 배후수요 대비 상가 공급여건이 유리하다는 뜻입니다. 산식 = 배후세대 밀도 45% + 세대/영업점 40% + 현재 네이버 임대매물 부담 15%. 영업점 API가 없으면 해당 항목은 중립값으로 계산되어 “잠정”으로 표시됩니다. 매수가격·공실·개별입지까지 포함한 최종 투자판정 점수는 아닙니다.');
      if(act==='save') saveSettingsFromUi(true);
      if(act==='copy') copyAnalysis();
      if(act==='csv') exportCsv();
      if(act==='marketRentToCalc') marketRentToCalculator();
      if(act==='focusListing'){
        const idx=+e.target.dataset.idx;
        const item=$$('.item_inner:not(.is-loading)')[idx];
        if(item){
          closeSheet();
          item.scrollIntoView({behavior:'smooth',block:'center'});
          item.classList.add('sanga-invest-focus');
          setTimeout(()=>item.classList.remove('sanga-invest-focus'),2600);
        }
      }
    });
    el.addEventListener('change',e=>{
      if(e.target.matches('[data-in="yield"]')){settings.targetYield=+e.target.value||6; render();}
      if(e.target.matches('[data-in="radius"]')){settings.radius=+e.target.value||500;}
      if(e.target.matches('[data-in="officetel"]')) settings.includeOfficetel=e.target.value==='1';
      if(e.target.matches('[data-in="manualUnits"]')){settings.manualUnits=e.target.value;render();}
      if(e.target.matches('[data-calc]')){ readCalculatorUi(); renderCalculator(); }
    });
    el.addEventListener('input',e=>{
      if(e.target.matches('[data-calc]')){ readCalculatorUi(); renderCalculator(); }
    });
  }
  function applyInputs(){
    const el=panel(); if(!el)return;
    $('[data-in="radius"]',el).value=String(settings.radius);
    $('[data-in="yield"]',el).value=String(settings.targetYield);
    $('[data-in="key"]',el).value=settings.serviceKey||'';
    $('[data-in="manualUnits"]',el).value=settings.manualUnits||'';
    $('[data-in="officetel"]',el).value=settings.includeOfficetel?'1':'0';
    $$('[data-calc]',el).forEach(inp=>{ const k=inp.dataset.calc; if(k in settings) inp.value=settings[k] ?? ''; });
  }
  function readUi(){
    const el=panel(); if(!el)return;
    settings.radius=+$('[data-in="radius"]',el).value||500;
    settings.targetYield=+$('[data-in="yield"]',el).value||6;
    settings.serviceKey=$('[data-in="key"]',el).value.trim();
    settings.manualUnits=$('[data-in="manualUnits"]',el).value.trim();
    settings.includeOfficetel=$('[data-in="officetel"]',el).value==='1';
    readCalculatorUi();
  }
  function calcNum(v, fallback=NaN){
    const n=Number(v); return Number.isFinite(n)?n:fallback;
  }
  function readCalculatorUi(){
    const el=panel(); if(!el)return;
    $$('[data-calc]',el).forEach(inp=>{
      const k=inp.dataset.calc;
      settings[k]=inp.value===''?'':calcNum(inp.value, settings[k]);
    });
  }
  function investmentCalc(){
    const purchase=calcNum(settings.purchasePrice);
    const loanRatio=clamp(calcNum(settings.loanRatio,0),0,100);
    const interest=Math.max(0,calcNum(settings.interestRate,0));
    const costRate=Math.max(0,calcNum(settings.acquisitionCostRate,0));
    const dep=Math.max(0,calcNum(settings.tenantDeposit,0));
    const rent=Math.max(0,calcNum(settings.tenantRent,0));
    const vacancy=clamp(calcNum(settings.vacancyRate,0),0,100);
    const ownerMonthly=Math.max(0,calcNum(settings.ownerMonthlyCost,0));
    if(!Number.isFinite(purchase)||purchase<=0) return null;
    const loan=purchase*loanRatio/100;
    const purchaseCosts=purchase*costRate/100;
    const cash=Math.max(0,purchase+purchaseCosts-loan-dep);
    const annualGrossRent=rent*12*(1-vacancy/100);
    const annualInterest=loan*interest/100;
    const annualOwnerCost=ownerMonthly*12;
    const annualCash=annualGrossRent-annualInterest-annualOwnerCost;
    const denominator=Math.max(0.0001,purchase-dep);
    const grossYield=annualGrossRent/denominator*100;
    const roe=cash>0?annualCash/cash*100:NaN;
    return {purchase,loan,purchaseCosts,cash,annualGrossRent,annualInterest,annualOwnerCost,annualCash,grossYield,roe,monthlyInterest:annualInterest/12};
  }
  function renderCalculator(){
    const c=investmentCalc();
    if(!c){
      ['calcLoan','calcMonthlyInterest','calcCash','calcAnnualCash','calcGrossYield','calcRoe'].forEach(k=>setv(k,'-'));
      return;
    }
    setv('calcLoan',`${fmt(c.loan)}만원`);
    setv('calcMonthlyInterest',`${fmt(c.monthlyInterest,1)}만원`);
    setv('calcCash',`${fmt(c.cash)}만원`);
    setv('calcAnnualCash',`${fmt(c.annualCash,1)}만원`);
    setv('calcGrossYield',`${fmt(c.grossYield,2)}%`);
    setv('calcRoe',Number.isFinite(c.roe)?`${fmt(c.roe,2)}%`:'-');
  }
  function marketRentToCalculator(){
    const l=latest?.listings||scanListings();
    if(!Number.isFinite(l.depositMedian)||!Number.isFinite(l.rentAmountMedian)){
      setv('warning','현재 읽힌 월세 매물이 부족해 대표 임대값을 가져올 수 없습니다.');
      return;
    }
    settings.tenantDeposit=Math.round(l.depositMedian);
    settings.tenantRent=Math.round(l.rentAmountMedian);
    applyInputs(); renderCalculator();
    setv('warning','현재 읽힌 월세 매물의 보증금·월세 중앙값을 투자 계산기에 입력했습니다. 서로 같은 매물의 한 쌍이 아닐 수 있으므로 참고값으로만 사용하세요.');
  }
  function saveSettingsFromUi(show){
    readUi(); chrome.storage.local.set({sangaInvestSettings:settings},()=>{if(show)setv('warning','설정을 저장했습니다. 지역 분석을 다시 누르면 새 설정으로 계산합니다.');});
  }
  function render(){
    if(!latest) return;
    const l=latest.listings||scanListings(); latest.listings=l;
    renderCalculator();
    setv('saleMean',Number.isFinite(l.saleMean)?`${fmt(l.saleMean,0)}만`:'-');
    setv('saleMedian',Number.isFinite(l.saleMedian)?`${fmt(l.saleMedian,0)}만`:'-');
    setv('saleTrimmed',Number.isFinite(l.saleTrimmed)?`${fmt(l.saleTrimmed,0)}만`:'-');
    setv('saleMin',Number.isFinite(l.saleMin)?`${fmt(l.saleMin,0)}만`:'-');
    setv('saleP10',Number.isFinite(l.saleP10)?`${fmt(l.saleP10,0)}만`:'-');
    setv('saleP90',Number.isFinite(l.saleP90)?`${fmt(l.saleP90,0)}만`:'-');
    setv('saleMax',Number.isFinite(l.saleMax)?`${fmt(l.saleMax,0)}만`:'-');
    setv('saleCount',`${l.sales.length}건`);
    setv('rentMean',Number.isFinite(l.rentMean)?`${fmt(l.rentMean,2)}만`:'-');
    setv('rentMedian',Number.isFinite(l.rentMedian)?`${fmt(l.rentMedian,2)}만`:'-');
    setv('rentTrimmed',Number.isFinite(l.rentTrimmed)?`${fmt(l.rentTrimmed,2)}만`:'-');
    setv('rentMin',Number.isFinite(l.rentMin)?`${fmt(l.rentMin,2)}만`:'-');
    setv('rentP10',Number.isFinite(l.rentP10)?`${fmt(l.rentP10,2)}만`:'-');
    setv('rentP90',Number.isFinite(l.rentP90)?`${fmt(l.rentP90,2)}만`:'-');
    setv('rentMax',Number.isFinite(l.rentMax)?`${fmt(l.rentMax,2)}만`:'-');
    setv('rentCount',`${l.rents.length}건`);
    const cheap=panel()?.querySelector('[data-v="cheapSales"]');
    if(cheap){
      if(!l.cheapSales.length){ cheap.innerHTML='<span class="sip-muted">현재 읽힌 매매 중 조건에 해당하는 저가 후보가 없습니다.</span>'; }
      else cheap.innerHTML=l.cheapSales.map(x=>{
        const floor=Number.isFinite(x.floor)?(x.floor<0?`B${Math.abs(x.floor)}`:`${x.floor}층`):'층 미상';
        return `<button class="sip-lowitem" data-act="focusListing" data-idx="${x.idx}"><b>${fmt(x.unit,0)}만/평</b><span>중앙값 ${fmt(x.discount,1)}% · ${floor} · ${fmt(x.areaPy,1)}평 · ${x.raw}</span></button>`;
      }).join('');
    }
    setv('depMed',Number.isFinite(l.depositMedian)?`${fmt(l.depositMedian)}만원`:'-');
    setv('rentAmtMed',Number.isFinite(l.rentAmountMedian)?`${fmt(l.rentAmountMedian)}만원`:'-');
    const cv=capValue(l.depositMedian,l.rentAmountMedian,settings.targetYield);
    setv('capValue',Number.isFinite(cv)?`${fmt(cv/10000,2)}억원`:'-');
    if(latest.households){
      const h=latest.households.households||0, s=latest.stores?.count;
      setv('households',`${fmt(h)}세대`);
      const density=h/(Math.PI*(settings.radius/1000)**2);
      setv('hhNote',`${settings.radius}m · ${latest.households.complexes.length}개 단지 · ${fmt(density)}세대/㎢`);
      setv('stores',Number.isFinite(s)?`${fmt(s)}개`:'API 키 필요');
      setv('hhPerStore',Number.isFinite(s)&&s>0?`${fmt(h/s,1)}세대`:'-');
      setv('storePer1000',Number.isFinite(s)&&h>0?`${fmt(s/h*1000,1)}개`:'-');
      const score=deriveScore({households:h,stores:s,radius:settings.radius,listings:l});
      setv('score',String(score.score)); setv('scoreLabel',score.label);
      const bar=panel()?.querySelector('[data-v="scoreBar"]'); if(bar)bar.style.width=`${score.score}%`;
      setv('region',latest.households.regionName || latest.households.cortarNo || '');
      const list=latest.households.complexes.slice(0,8).map(c=>`${c.name||c.no} · ${fmt(c.hh)}세대 · ${fmt(c.distance)}m`).join('<br>');
      const ce=panel()?.querySelector('[data-v="complexes"]'); if(ce)ce.innerHTML=list||'반경 내 확인 가능한 주거단지가 없습니다.';
      const units=+settings.manualUnits;
      const rentPer1000=h>0?l.rents.length/h*1000:NaN;
      const salePer1000=h>0?l.sales.length/h*1000:NaN;
      setv('manualUnitKpi',Number.isFinite(units)&&units>0&&h>0?`상가 호실 기준: ${fmt(h/units,1)}세대/호실 · 1천세대당 ${fmt(units/h*1000,1)}호실 · 현재 임대매물 ${fmt(rentPer1000,1)}건/1천세대`:`상가 전체 호실 수를 알면 입력하세요. 현재 네이버 매물은 임대 ${Number.isFinite(rentPer1000)?fmt(rentPer1000,1):'-'}건/1천세대, 매매 ${Number.isFinite(salePer1000)?fmt(salePer1000,1):'-'}건/1천세대입니다.`);
    }
  }
  async function refreshAll(userTriggered=false){
    mount(); readUi();
    latest={listings:scanListings(),households:null,stores:null}; render();
    const center=getCenter();
    if(center) lastCenterSignature=`${center.lat.toFixed(5)},${center.lon.toFixed(5)},${center.zoom}`;
    if(!center){setv('warning','현재 모바일 지도 URL에서 중심좌표를 찾지 못했습니다. 네이버부동산 지도 화면에서 지도를 한 번 움직인 뒤 다시 지역 분석을 눌러보세요.');return;}
    setv('warning','배후세대와 영업점 수를 조회 중입니다…');
    try{
      latest.households=await getHouseholds(center,settings.radius);
      render();
      try{ latest.stores=await getStoreCount(center,settings.radius); }
      catch(e){ latest.stores={count:NaN,error:e.message}; }
      render();
      if(!settings.serviceKey){
        setv('warning','배후세대 자동 집계 완료. 영업점 수까지 자동 계산하려면 공공데이터포털 「소상공인 상가(상권)정보 API」의 Decoding 인증키를 입력하세요.');
      }else if(latest.stores?.error){
        setv('warning',`배후세대는 완료했지만 영업점 조회 실패: ${latest.stores.error}`);
      }else{
        setv('warning','분석 완료. 상권 수급지수는 높을수록 공급 대비 배후수요가 유리하다는 뜻이며, 매수가격까지 포함한 투자등급은 아닙니다.');
      }
    }catch(e){
      setv('warning',`배후세대 조회 실패: ${e.message}. 네이버가 API 구조를 변경했거나 현재 화면에 행정구역 정보가 없을 수 있습니다.`);
    }
  }
  function analysisText(){
    const l=latest?.listings||scanListings(); const h=latest?.households?.households; const s=latest?.stores?.count;
    const sc=Number.isFinite(h)?deriveScore({households:h,stores:s,radius:settings.radius,listings:l}):null;
    const units=+settings.manualUnits;
    const ic=investmentCalc();
    return [
      `YB LOCUS Android v0.7`,
      `반경: ${settings.radius}m`,
      `배후세대: ${Number.isFinite(h)?fmt(h)+'세대':'-'}`,
      `영업점: ${Number.isFinite(s)?fmt(s)+'개':'-'}`,
      `세대/영업점: ${Number.isFinite(h)&&Number.isFinite(s)&&s>0?fmt(h/s,1):'-'}`,
      `1천세대당 영업점: ${Number.isFinite(h)&&Number.isFinite(s)&&h>0?fmt(s/h*1000,1):'-'}`,
      `상가호실수(수동): ${Number.isFinite(units)&&units>0?fmt(units):'-'}`,
      `세대/상가호실: ${Number.isFinite(h)&&units>0?fmt(h/units,1):'-'}`,
      `수급지수: ${sc?sc.score+'점 '+sc.label:'-'}`,
      `매매 평당 전체평균/중앙값/보정평균: ${Number.isFinite(l.saleMean)?fmt(l.saleMean):'-'} / ${Number.isFinite(l.saleMedian)?fmt(l.saleMedian):'-'} / ${Number.isFinite(l.saleTrimmed)?fmt(l.saleTrimmed):'-'}만원`,
      `매매 평당 최저/하위10%/상위10%/최고: ${Number.isFinite(l.saleMin)?fmt(l.saleMin):'-'} / ${Number.isFinite(l.saleP10)?fmt(l.saleP10):'-'} / ${Number.isFinite(l.saleP90)?fmt(l.saleP90):'-'} / ${Number.isFinite(l.saleMax)?fmt(l.saleMax):'-'}만원`,
      `월세 평당 전체평균/중앙값/보정평균: ${Number.isFinite(l.rentMean)?fmt(l.rentMean,2):'-'} / ${Number.isFinite(l.rentMedian)?fmt(l.rentMedian,2):'-'} / ${Number.isFinite(l.rentTrimmed)?fmt(l.rentTrimmed,2):'-'}만원`,
      `저가 후보 수: ${l.cheapSales.length}건 (중앙값 대비 -10% 이상 또는 하위10%)`,
      `매매/월세 건수: ${l.sales.length}/${l.rents.length}`,
      `목표수익률: ${settings.targetYield}%`,
      `대표 월세 수익환산가: ${Number.isFinite(capValue(l.depositMedian,l.rentAmountMedian,settings.targetYield))?fmt(capValue(l.depositMedian,l.rentAmountMedian,settings.targetYield)/10000,2)+'억원':'-'}`,
      `대상 매입가/대출/실투자금: ${ic?fmt(ic.purchase)+' / '+fmt(ic.loan)+' / '+fmt(ic.cash)+'만원':'-'}`,
      `월 이자/연 순현금흐름: ${ic?fmt(ic.monthlyInterest,1)+' / '+fmt(ic.annualCash,1)+'만원':'-'}`,
      `단순 임대수익률/대출후 현금수익률: ${ic?fmt(ic.grossYield,2)+'% / '+(Number.isFinite(ic.roe)?fmt(ic.roe,2)+'%':'-'):'-'}`
    ].join('\n');
  }
  async function copyAnalysis(){
    try{
      const t=analysisText();
      if(typeof SangaNative!=='undefined' && SangaNative.copyText){ SangaNative.copyText(window.__SANGA_BRIDGE_TOKEN__||'', t); }
      else await navigator.clipboard.writeText(t);
      setv('warning','분석 내용을 클립보드에 복사했습니다.');
    }catch(e){setv('warning','복사에 실패했습니다.');}
  }
  function csvEsc(v){const s=String(v??'');return /[",\n]/.test(s)?`"${s.replace(/"/g,'""')}"`:s;}
  function exportCsv(){
    const l=latest?.listings||scanListings();
    const rows=[['구분','층','전용평','가격/조건','평당가(만원)','중앙값대비(%)','저가후보','보증금(만원)','월세(만원)']];
    l.rows.forEach(x=>{
      const med=x.kind==='sale'?l.saleMedian:l.rentMedian;
      const disc=Number.isFinite(med)&&med>0?(x.unit/med-1)*100:NaN;
      const low=x.kind==='sale'&&l.cheapSales.some(c=>c.idx===x.idx)?'Y':'';
      rows.push([x.kind==='sale'?'매매':'월세',x.floor??'',x.areaPy.toFixed(2),x.raw,x.unit.toFixed(2),Number.isFinite(disc)?disc.toFixed(1):'',low,x.deposit??'',x.rent??'']);
    });
    const csv='\uFEFF'+rows.map(r=>r.map(csvEsc).join(',')).join('\r\n');
    const name=`상가분석_${new Date().toISOString().slice(0,10)}.csv`;
    try{
      if(typeof SangaNative!=='undefined' && SangaNative.saveTextFile){
        const result=SangaNative.saveTextFile(window.__SANGA_BRIDGE_TOKEN__||'', name,csv);
        setv('warning', result || 'CSV를 저장했습니다.');
        return;
      }
    }catch(e){}
    try{
      const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}), url=URL.createObjectURL(blob), a=document.createElement('a');
      a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }catch(e){ setv('warning','CSV 저장에 실패했습니다.'); }
  }
  function load(){
    chrome.storage.local.get(['sangaInvestSettings'],r=>{
      settings={...DEFAULTS,...(r.sangaInvestSettings||{})}; mount();applyInputs();latest={listings:scanListings()};render();
      setTimeout(()=>refreshAll(false),1200);
    });
  }
  const obs=new MutationObserver((mutations)=>{
    // 분석 패널 자체의 숫자/문구 갱신은 관찰 대상에서 제외한다.
    // v0.6에서는 패널 렌더링이 다시 observer를 깨워 반복 스캔을 만들 수 있어 스크롤이 버벅였다.
    const relevant = mutations.some(m=>{
      const t=m.target?.nodeType===1 ? m.target : m.target?.parentElement;
      if(!t) return false;
      if(t.closest?.(`#${ID},#${LAUNCHER_ID},#${BACKDROP_ID}`)) return false;
      return true;
    });
    if(!relevant) return;

    const sheetOpen = panel() && !panel().classList.contains('sip-sheet-closed');
    if(!sheetOpen){
      clearTimeout(typeSheetTimer);
      typeSheetTimer=setTimeout(simplifyPropertyTypeSheet,220);
    }
    clearTimeout(refreshTimer); refreshTimer=setTimeout(()=>{
      const hrefChanged=location.href!==lastHref;
      if(hrefChanged) lastHref=location.href;

      // 분석 시트가 열려 있을 때는 자동 매물 전체 재스캔을 잠시 멈춰 스크롤 우선.
      const sheetStillOpen = panel() && !panel().classList.contains('sip-sheet-closed');
      if(latest && !sheetStillOpen){ latest.listings=scanListings(); render(); }

      const c=getCenter();
      const sig=c?`${c.lat.toFixed(5)},${c.lon.toFixed(5)},${c.zoom}`:'';
      if(sig && sig!==lastCenterSignature){
        lastCenterSignature=sig;
        clearTimeout(regionRefreshTimer);
        regionRefreshTimer=setTimeout(()=>refreshAll(false),1300);
      }
    },700);
  });
  function boot(){
    load();
    simplifyPropertyTypeSheet();
    setTimeout(simplifyPropertyTypeSheet,700);
    setTimeout(simplifyPropertyTypeSheet,1800);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
  obs.observe(document.documentElement,{subtree:true,childList:true});
})();
