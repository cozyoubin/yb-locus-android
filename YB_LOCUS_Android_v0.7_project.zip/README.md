# YB LOCUS Android v0.6

Mobile-first Android build.

Changes from v0.5:
- Uses a mobile Android user agent so Naver Land can render its mobile UI instead of shrinking the entire desktop page.
- Disables overview shrink-to-fit.
- Enables pinch zoom and increases WebView text scaling.
- Injects a mobile viewport meta tag.
- Enlarges YB LOCUS analysis controls and touch targets.

Package: `com.yblocus.app`
Version: `0.6.0`


## v0.7 mobile UX
- Naver page text zoom restored to 100% to prevent clipped controls.
- Property type sheet hides non-commercial categories and keeps 상가/사무실.
- Analyzer launcher hides while Naver property-type sheet is open.
- Removed backdrop blur and recursive observer work while analyzer is open to improve scroll performance.
