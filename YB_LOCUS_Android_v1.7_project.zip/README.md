# YB LOCUS Android v1.7

Mobile-first Android WebView wrapper for Naver Land commercial analysis.

## v1.7 fixes
- 네이버 지도 자체 단위도 `평`을 기본으로 자동 전환. 분석창에서는 ㎡당 전환 옵션 유지.
- 상가/사무실을 최초 기본값으로 유지하고 지역 이동 중 아파트 모드로 튀는 경우 commercial URL을 복구. 사용자가 직접 다른 매물유형을 선택하면 그 선택을 존중.
- 분석 보조문구가 다시 파싱되어 면적이 0.5평처럼 망가지는 재귀 파싱 버그 차단. `전용 X평` 표기도 정확히 파싱.
- 저가매물 TOP3에서 매물 위치로 이동한 뒤 Android 뒤로가기를 누르면 앱 종료 대신 분석 화면으로 복귀.
- 분석창이 열린 상태에서 Android 뒤로가기를 누르면 분석창만 닫힘.

Package: `com.yblocus.app`
Version: `1.7.0`
