# YB LOCUS Android v2.7

- Screenshot-driven bugfix build.
- More robust top filter detection for Naver DOM variants.
- Default target: 상가+사무실 / 매매+월세 / 평.
- Analyzer no longer opens the listing sheet merely to discover an API template.
- Naver API bridge tries cookie/public request first, bearer auth only after 401/403.
- Analysis errors now include region/API-template diagnostics for screenshot-only debugging.
