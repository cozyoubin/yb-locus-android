# YB LOCUS Android v0.6

Mobile-first Android build.

Changes from v0.5:
- Uses a mobile Android user agent so Naver Land can render its mobile UI instead of shrinking the entire desktop page.
- Disables overview shrink-to-fit.
- Enables pinch zoom and increases WebView text scaling.
- Injects a mobile viewport meta tag.
- Enlarges YB LOCUS analysis controls and touch targets.

Package: `com.yblocus.app`
Version: `0.6.0`


## v0.7 mobile UX
- Naver page text zoom restored to 100% to prevent clipped controls.
- Property type sheet hides non-commercial categories and keeps 상가/사무실.
- Analyzer launcher hides while Naver property-type sheet is open.
- Removed backdrop blur and recursive observer work while analyzer is open to improve scroll performance.


## v0.8 touch / overlap fix
- Moves the YB LOCUS launcher upward so it no longer covers Naver's bottom `매물` button.
- Makes only the analyzer body scroll; the fixed sheet itself no longer scrolls.
- Removes nested overscroll / momentum containment that could consume the first reverse swipe in Android WebView.
- Keeps the commercial-only property filter behavior from v0.7.


## v1.0 non-overlap toolbar
- Moves the Android-native analysis control from the bottom to a dedicated top app bar.
- The Naver WebView is laid out below the bar instead of being covered by it.
- Prevents overlap with Naver's bottom `매물` pill and Android system navigation controls.
- Keeps the v0.9 full-screen analyzer and stable touch-scroll behavior.


## v1.2 startup-safe system-bar spacing
- Reverts the v1.1 WindowInsets listener.
- Adds safe top/bottom spacing using Android system-bar dimension resources with conservative fallbacks.
- Keeps the YB LOCUS / analysis bar below the status area and the Naver bottom listing control above 3-button navigation.
