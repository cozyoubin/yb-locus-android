package com.yblocus.app;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final String HOME = "https://new.land.naver.com/offices";
    private static final String APP_VERSION = "0.6.0";
    private static final int REQ_LOCATION = 701;
    private WebView webView;
    private ProgressBar progressBar;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private final String bridgeToken = UUID.randomUUID().toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(17, 24, 39));

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);

        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(3));
        pp.topMargin = 0;
        root.addView(progressBar, pp);
        setContentView(root);

        WebView.setWebContentsDebuggingEnabled(false);
        configureWebView();
        webView.addJavascriptInterface(new NativeBridge(this, bridgeToken), "SangaNative");

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(resolveStartUrl(getIntent()));
        }
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setTextZoom(112);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) s.setSafeBrowsingEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        // Android에서는 모바일 네이버 부동산 UI를 우선 사용한다.
        // 데스크톱 페이지 전체를 축소해 끼워 넣는 방식은 조작성과 가독성이 크게 떨어진다.
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 16; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Mobile Safari/537.36");
        s.setLoadWithOverviewMode(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cm.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    String host = u.getHost();
                    // JavaScript bridge가 일반 네이버 서비스에 노출되지 않도록 부동산 호스트만 앱 내부에서 연다.
                    if (host != null && isNaverLandHost(host)) return false;
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                    return true;
                }
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                injectAnalyzer();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (Build.VERSION.SDK_INT < 23 ||
                        (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                         checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)) {
                    callback.invoke(origin, true, false);
                    return;
                }
                geoOrigin = origin;
                geoCallback = callback;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            }
        });
    }

    private void injectAnalyzer() {
        String url = webView.getUrl();
        if (url == null || !isNaverLand(url)) return;
        try {
            String bridge = readAssetText("bridge.js").replace("__SANGA_BRIDGE_TOKEN__", bridgeToken);
            injectJs("window.__SANGA_BRIDGE_TOKEN__=" + JSONObject.quote(bridgeToken) + ";");
            // 모바일 WebView에서 사이트가 PC 폭으로 축소되지 않도록 viewport를 명시한다.
            injectJs("(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}m.content='width=device-width, initial-scale=1.0, maximum-scale=5.0, user-scalable=yes';})();");
            injectJs(bridge);
            injectCss(readAssetText("investment_mobile.css"));
            // PC용 contents.js는 중개사/등록일 등을 제거하는 로직이 있어 모바일에서는 사용하지 않는다.
            // 모바일 전용 분석기가 원본 DOM을 보존하면서 평수·평당가만 안전하게 덧붙인다.
            injectJs(readAssetText("investment_mobile.js"));
        } catch (Exception e) {
            Toast.makeText(this, "분석기 로드 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void injectJs(String js) {
        webView.evaluateJavascript("(function(){\n" + js + "\n})();", null);
    }

    private void injectCss(String css) {
        String q = JSONObject.quote(css);
        String js = "(function(){var id='sanga-invest-mobile-css';var x=document.getElementById(id);if(!x){x=document.createElement('style');x.id=id;document.documentElement.appendChild(x);}x.textContent=" + q + ";})();";
        webView.evaluateJavascript(js, null);
    }

    private String readAssetText(String name) throws Exception {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private String resolveStartUrl(Intent intent) {
        if (intent != null) {
            if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
                String u = intent.getData().toString();
                if (isNaverLand(u)) return u;
            }
            if (Intent.ACTION_SEND.equals(intent.getAction())) {
                String text = intent.getStringExtra(Intent.EXTRA_TEXT);
                if (text != null) {
                    String u = firstNaverLandUrl(text);
                    if (u != null) return u;
                }
            }
        }
        return HOME;
    }

    private static String firstNaverLandUrl(String text) {
        int p = text.indexOf("https://");
        while (p >= 0) {
            int end = text.indexOf(' ', p);
            String u = end < 0 ? text.substring(p) : text.substring(p, end);
            u = u.replaceAll("[\\)\\]>,.;]+$", "");
            if (isNaverLand(u)) return u;
            p = text.indexOf("https://", p + 8);
        }
        return null;
    }

    private static boolean isNaverLandHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("land.naver.com") || h.endsWith(".land.naver.com");
    }

    private static boolean isNaverLand(String url) {
        try {
            Uri u = Uri.parse(url);
            return isNaverLandHost(u.getHost());
        } catch (Exception e) { return false; }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        webView.loadUrl(resolveStartUrl(intent));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && geoCallback != null) {
            boolean ok = false;
            for (int r : grantResults) if (r == PackageManager.PERMISSION_GRANTED) { ok = true; break; }
            geoCallback.invoke(geoOrigin, ok, false);
            geoCallback = null;
            geoOrigin = null;
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    public static class NativeBridge {
        private final MainActivity activity;
        private final android.content.SharedPreferences prefs;
        private final String token;

        NativeBridge(MainActivity activity, String token) {
            this.activity = activity;
            this.token = token;
            this.prefs = activity.getSharedPreferences("yb_locus", Context.MODE_PRIVATE);
        }

        private boolean authorized(String supplied) {
            return supplied != null && token.equals(supplied);
        }

        @JavascriptInterface
        public String getStorageJson(String suppliedToken) {
            if (!authorized(suppliedToken)) return "{}";
            return prefs.getString("js_storage", "{}");
        }

        @JavascriptInterface
        public void setStorageJson(String suppliedToken, String json) {
            if (!authorized(suppliedToken)) return;
            if (json == null || json.length() > 2000000) return;
            prefs.edit().putString("js_storage", json).apply();
        }

        @JavascriptInterface
        public String assetDataUrl(String suppliedToken, String name) {
            if (!authorized(suppliedToken)) return "";
            if (name == null) return "";
            if (!name.equals("config.json")) return "";
            try (InputStream in = activity.getAssets().open(name);
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] b = new byte[4096]; int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
                String mime = "application/json";
                return "data:" + mime + ";base64," + Base64.getEncoder().encodeToString(out.toByteArray());
            } catch (Exception e) { return ""; }
        }

        @JavascriptInterface
        public String httpGet(String suppliedToken, String url) {
            JSONObject out = new JSONObject();
            if (!authorized(suppliedToken)) {
                try { out.put("ok", false); out.put("error", "unauthorized"); } catch (Exception ignored) {}
                return out.toString();
            }
            HttpURLConnection c = null;
            try {
                URL u = new URL(url);
                String h = u.getHost().toLowerCase(Locale.ROOT);
                boolean allowed = h.equals("new.land.naver.com") || h.equals("m.land.naver.com") || h.equals("fin.land.naver.com") || h.equals("apis.data.go.kr");
                if (!allowed || !"https".equalsIgnoreCase(u.getProtocol())) throw new SecurityException("허용되지 않은 주소");

                c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(12000);
                c.setReadTimeout(18000);
                c.setInstanceFollowRedirects(true);
                c.setRequestMethod("GET");
                c.setRequestProperty("Accept", "application/json, text/plain, */*");
                c.setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9,en;q=0.6");
                c.setRequestProperty("Referer", "https://new.land.naver.com/");
                c.setRequestProperty("User-Agent", activity.webView.getSettings().getUserAgentString());
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);

                int code = c.getResponseCode();
                InputStream stream = code >= 200 && code < 400 ? c.getInputStream() : c.getErrorStream();
                String text = readAll(stream);
                out.put("ok", code >= 200 && code < 300);
                out.put("status", code);
                out.put("text", text);
                if (!(code >= 200 && code < 300)) out.put("error", "HTTP " + code);
            } catch (Exception e) {
                try {
                    out.put("ok", false);
                    out.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
                } catch (Exception ignored) {}
            } finally {
                if (c != null) c.disconnect();
            }
            return out.toString();
        }

        private static String readAll(InputStream in) throws Exception {
            if (in == null) return "";
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                StringBuilder s = new StringBuilder();
                char[] b = new char[8192]; int n;
                while ((n = r.read(b)) >= 0) s.append(b, 0, n);
                return s.toString();
            }
        }

        @JavascriptInterface
        public void copyText(String suppliedToken, String text) {
            if (!authorized(suppliedToken)) return;
            activity.runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("YB LOCUS", text == null ? "" : text));
                Toast.makeText(activity, "분석 내용을 복사했습니다.", Toast.LENGTH_SHORT).show();
            });
        }

        @JavascriptInterface
        public String saveTextFile(String suppliedToken, String filename, String text) {
            if (!authorized(suppliedToken)) return "CSV 저장 권한 확인 실패";
            String safeName = (filename == null || filename.trim().isEmpty()) ? "상가분석.csv" : filename.replaceAll("[\\\\/:*?\"<>|]", "_");
            try {
                byte[] bytes = (text == null ? "" : text).getBytes(StandardCharsets.UTF_8);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/YB LOCUS");
                    Uri uri = activity.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new Exception("저장 위치 생성 실패");
                    try (OutputStream os = activity.getContentResolver().openOutputStream(uri)) { os.write(bytes); }
                    return "다운로드/YB LOCUS/" + safeName + " 에 저장했습니다.";
                } else {
                    File dir = new File(activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "YB LOCUS");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("폴더 생성 실패");
                    File f = new File(dir, safeName);
                    try (FileOutputStream os = new FileOutputStream(f)) { os.write(bytes); }
                    return "앱 다운로드 폴더에 " + safeName + " 을 저장했습니다.";
                }
            } catch (Exception e) {
                return "CSV 저장 실패: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void openExternal(String suppliedToken, String url) {
            if (!authorized(suppliedToken)) return;
            activity.runOnUiThread(() -> {
                try { activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception e) { Toast.makeText(activity, "링크를 열 수 없습니다.", Toast.LENGTH_SHORT).show(); }
            });
        }
    }
}
