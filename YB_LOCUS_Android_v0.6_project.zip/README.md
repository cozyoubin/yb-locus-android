# YB LOCUS

**Commercial Intelligence for retail real estate**

YB LOCUS is an Android analysis tool built around Naver Real Estate browsing. It keeps the original listing information visible while adding commercial-property analytics such as price-per-pyeong, low-price candidates, trade-area supply/demand metrics, hinterland households, rental-value estimates, and leveraged cash-return calculations.

## Current version

- Android v0.5.0
- Package: `com.yblocus.app`
- Minimum Android: 8.0 (API 26)
- Target SDK: Android 16 / API 36

## Main functions

- Sale / rent price-per-pyeong analysis
- Mean, median, trimmed mean, lower/upper deciles, min/max
- Low-price candidate detection without removing genuine discounted listings
- Hinterland-household analysis by radius
- Commercial supply-demand index (higher = more favorable demand relative to supply)
- Target property calculator: purchase price, LTV, interest, deposit, rent, vacancy, cash invested and ROE
- CSV export to `Download/YB LOCUS`
- Naver Real Estate share-link handling

## APK build

GitHub Actions builds the debug APK automatically on pushes to `main` and can also be run manually from the **Actions** tab.

Artifact name: `YB-LOCUS-Android-v0.5-debug`
