# YB LOCUS Android v2.2

- Default filters: 상가 + 사무실 / 매매 + 월세 / 평
- Analysis now fetches Naver listing API data for the current area instead of relying only on visible listing cards.
- Household analysis reuses the cortarNo observed from Naver's own network requests when available.
