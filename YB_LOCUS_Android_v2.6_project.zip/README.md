# YB LOCUS Android v2.6.0 — recovery build

v2.6 is a recovery build after v2.5 regressed the Naver initial filters and returned 0 listing rows.

Changes:
- Do not clear Naver WebStorage on launch.
- Verify and set the actual Naver top filters once per app launch: 상가 + 사무실 / 매매 + 월세.
- Keep 평 as the default display unit.
- Do not run hidden full analysis during app startup.
- When analysis starts, temporarily open the exact bottom `매물 N` list only to capture Naver's live article API request/session, then close it automatically.
- Reuse that live request and paginate to the end automatically; no user scrolling is required.
- Capture Naver Authorization headers from fetch/XHR when available, with native API fallback.
- Track the Naver listing bottom sheet so Android Back collapses it instead of closing the app.
- Register Android 13+ OnBackInvoked callback and preserve the TOP3 detail -> analyzer return path.
- Do not show a numeric supply-demand score when household data is 0.
